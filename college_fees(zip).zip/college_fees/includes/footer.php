        </div> <!-- End content -->
        
        <div style="background: #f8f9fa; padding: 20px; text-align: center; border-top: 1px solid #ddd;">
            <p>&copy; <?php echo date('Y'); ?> College Fees Management System. All rights reserved.</p>
            <p style="font-size: 12px; color: #666; margin-top: 5px;">
                Developed for DBMS Project | PHP + MySQL
            </p>
        </div>
    </div> <!-- End container -->
</body>
</html>
